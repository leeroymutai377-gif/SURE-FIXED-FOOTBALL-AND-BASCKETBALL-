import streamlit as st
import pandas as pd
import numpy as np
import math
from collections import defaultdict
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, log_loss

st.set_page_config(
    page_title="Basketball Predictor",
    page_icon="🏀",
    layout="centered",
    initial_sidebar_state="collapsed",
)

# ---------- Original predictor engine ----------
class EloEngine:
    def __init__(self, k=20, hca=100, carryover=0.75):
        self.k = k
        self.hca = hca
        self.carryover = carryover
        self.ratings = defaultdict(lambda: 1500.0)

    def expected(self, home, away):
        diff = (self.ratings[home] + self.hca) - self.ratings[away]
        return 1.0 / (1.0 + 10 ** (-diff / 400.0))

    def update(self, home, away, home_won, margin):
        exp = self.expected(home, away)
        actual = 1.0 if home_won else 0.0
        mov = math.log(abs(margin) + 1.0) * (2.2 / (abs(margin) + 2.2))
        delta = self.k * mov * (actual - exp)
        self.ratings[home] += delta
        self.ratings[away] -= delta


class FeatureBuilder:
    def __init__(self):
        self.hist = defaultdict(list)
        self.last_date = {}

    def features(self, home, away, date):
        f = {}
        for tag, team in (("h", home), ("a", away)):
            games = self.hist[team]
            if games:
                pf = np.mean([g[0] for g in games[-10:]])
                pa = np.mean([g[1] for g in games[-10:]])
                f[f"{tag}_net"] = pf - pa
                f[f"{tag}_pace"] = pf + pa
                f[f"{tag}_win10"] = np.mean(
                    [1.0 if g[0] > g[1] else 0.0 for g in games[-10:]]
                )
            else:
                f[f"{tag}_net"] = 0.0
                f[f"{tag}_pace"] = 220.0
                f[f"{tag}_win10"] = 0.5
            ld = self.last_date.get(team)
            f[f"{tag}_rest"] = min((date - ld).days, 7) if ld else 3
        return f

    def add(self, home, away, hs, as_, date):
        self.hist[home].append((hs, as_, date))
        self.hist[away].append((as_, hs, date))
        self.last_date[home] = date
        self.last_date[away] = date


class Ensemble:
    def __init__(self):
        self.scaler = StandardScaler()
        self.lr = LogisticRegression(max_iter=2000, C=0.5)
        self.gb = GradientBoostingClassifier(
            n_estimators=300, max_depth=3, learning_rate=0.05,
            subsample=0.8, random_state=42
        )
        self.weights = (0.35, 0.35, 0.30)

    def fit(self, X, y):
        Xs = self.scaler.fit_transform(X)
        self.lr.fit(Xs, y)
        self.gb.fit(Xs, y)

    def predict_proba(self, X, elo_probs):
        Xs = self.scaler.transform(X)
        p_lr = self.lr.predict_proba(Xs)[:, 1]
        p_gb = self.gb.predict_proba(Xs)[:, 1]
        w = self.weights
        return w[0] * elo_probs + w[1] * p_lr + w[2] * p_gb


def prepare_history(df):
    df = df.copy()
    df["date"] = pd.to_datetime(df["date"])
    df = df.sort_values("date").reset_index(drop=True)
    return df


def train_and_predict(df, home, away):
    elo = EloEngine()
    fb = FeatureBuilder()
    X, y, elo_p = [], [], []

    for _, r in df.iterrows():
        h, a = str(r["home"]), str(r["away"])
        feats = fb.features(h, a, r["date"])
        elo_p.append(elo.expected(h, a))
        X.append(list(feats.values()))
        result = 1 if r["home_score"] > r["away_score"] else 0
        y.append(result)
        elo.update(h, a, result == 1, r["home_score"] - r["away_score"])
        fb.add(h, a, r["home_score"], r["away_score"], r["date"])

    X = np.asarray(X)
    y = np.asarray(y)
    elo_p = np.asarray(elo_p)

    if len(np.unique(y)) < 2:
        raise ValueError("The historical data must contain both home wins and away wins.")

    model = Ensemble()
    model.fit(X, y)

    # Important: use the most recent historical date as the prediction reference.
    last = df["date"].max()
    feats = fb.features(home, away, last)
    ep = elo.expected(home, away)
    p = float(model.predict_proba(
        np.asarray([list(feats.values())]), np.asarray([ep])
    )[0])
    return p, ep, elo, fb


def backtest(df, split=0.75):
    elo = EloEngine()
    fb = FeatureBuilder()
    X, y, elo_p = [], [], []

    for _, r in df.iterrows():
        h, a = str(r["home"]), str(r["away"])
        feats = fb.features(h, a, r["date"])
        elo_p.append(elo.expected(h, a))
        X.append(list(feats.values()))
        result = 1 if r["home_score"] > r["away_score"] else 0
        y.append(result)
        elo.update(h, a, result == 1, r["home_score"] - r["away_score"])
        fb.add(h, a, r["home_score"], r["away_score"], r["date"])

    X = np.asarray(X)
    y = np.asarray(y)
    elo_p = np.asarray(elo_p)
    cut = max(1, int(len(X) * split))
    if cut >= len(X):
        raise ValueError("Not enough games for a test set. Use more historical games.")

    model = Ensemble()
    model.fit(X[:cut], y[:cut])
    probs = model.predict_proba(X[cut:], elo_p[cut:])
    preds = (probs >= 0.5).astype(int)

    conf = np.abs(probs - 0.5) >= 0.10
    return {
        "games_tested": len(y) - cut,
        "overall_accuracy": accuracy_score(y[cut:], preds),
        "log_loss": log_loss(y[cut:], probs, labels=[0, 1]),
        "high_conf_games": int(conf.sum()),
        "high_conf_accuracy": accuracy_score(y[cut:][conf], preds[conf])
            if conf.sum() else float("nan"),
        "ratings": dict(elo.ratings),
    }


# ---------- Mobile UI ----------
st.markdown("""
<style>
.block-container {max-width: 850px; padding-top: 1.2rem; padding-bottom: 3rem;}
.hero {
    padding: 1.4rem; border-radius: 20px; margin-bottom: 1rem;
    background: linear-gradient(135deg,#111827,#2563eb);
    color: white; text-align:center;
}
.hero h1 {margin:0; font-size:2rem;}
.hero p {margin:.45rem 0 0; opacity:.9;}
.card {padding:1rem; border-radius:16px; border:1px solid #e5e7eb; background:#fff;}
.big {font-size:2.3rem; font-weight:800; text-align:center;}
.muted {color:#6b7280; font-size:.9rem;}
@media (max-width: 600px) {
    .hero h1 {font-size:1.55rem;}
    .big {font-size:1.9rem;}
}
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="hero">
  <h1>🏀 Basketball Predictor</h1>
  <p>Elo + Logistic Regression + Gradient Boosting ensemble</p>
</div>
""", unsafe_allow_html=True)

with st.sidebar:
    st.header("About")
    st.write("Upload historical basketball games as CSV, then predict a matchup.")
    st.caption("Predictions are statistical estimates, not guarantees.")

uploaded = st.file_uploader("📁 Upload historical games CSV", type=["csv"])

if uploaded is None:
    st.info("Upload a CSV to start.")
    st.markdown("### Required CSV columns")
    st.code("date,home,away,home_score,away_score")
    st.markdown("Example:")
    st.code("""date,home,away,home_score,away_score
2026-01-01,LAL,BOS,110,106
2026-01-02,NYK,MIA,104,111
2026-01-03,BOS,NYK,115,109""")
    st.stop()

try:
    df = prepare_history(pd.read_csv(uploaded, parse_dates=["date"]))
except Exception as e:
    st.error(f"Could not read the CSV: {e}")
    st.stop()

required = {"date","home","away","home_score","away_score"}
missing = required - set(df.columns)
if missing:
    st.error("Missing columns: " + ", ".join(sorted(missing)))
    st.stop()

if len(df) < 20:
    st.warning("This model can run, but a small historical dataset may produce unstable estimates.")

teams = sorted(set(df["home"].astype(str)) | set(df["away"].astype(str)))

st.success(f"Loaded {len(df):,} historical games and {len(teams)} teams.")

tab1, tab2 = st.tabs(["🏀 Predict", "📊 Backtest"])

with tab1:
    c1, c2 = st.columns(2)
    with c1:
        home = st.selectbox("Home team", teams, index=0)
    with c2:
        away_options = [t for t in teams if t != home] or teams
        away = st.selectbox("Away team", away_options, index=0)

    if st.button("🔮 Predict matchup", type="primary", use_container_width=True):
        if home == away:
            st.error("Choose two different teams.")
        else:
            try:
                p, ep, _, _ = train_and_predict(df, home, away)
                hp = p * 100
                ap = 100 - hp
                pick = home if p >= 0.5 else away
                conf = abs(p - 0.5) * 200

                st.markdown("---")
                a, b = st.columns(2)
                with a:
                    st.markdown(f"<div class='card'><div class='muted'>HOME</div><div class='big'>{hp:.1f}%</div><b>{home}</b></div>", unsafe_allow_html=True)
                with b:
                    st.markdown(f"<div class='card'><div class='muted'>AWAY</div><div class='big'>{ap:.1f}%</div><b>{away}</b></div>", unsafe_allow_html=True)

                st.subheader("Model output")
                st.metric("Ensemble home probability", f"{hp:.1f}%")
                st.metric("Elo-only home probability", f"{ep*100:.1f}%")
                st.metric("Model separation", f"{conf:.0f}/100")
                st.info(f"Model-selected side: **{pick}**")
                if conf < 15:
                    st.warning("Low model separation. Treat this matchup as uncertain.")
            except Exception as e:
                st.error(f"Prediction error: {e}")

with tab2:
    split = st.slider("Training share", 0.50, 0.90, 0.75, 0.05)
    if st.button("▶️ Run backtest", use_container_width=True):
        try:
            r = backtest(df, split)
            c1, c2 = st.columns(2)
            c1.metric("Games tested", r["games_tested"])
            c2.metric("Overall accuracy", f"{r['overall_accuracy']*100:.1f}%")
            c1.metric("Log loss", f"{r['log_loss']:.4f}")
            hc = r["high_conf_accuracy"]
            c2.metric("High-confidence accuracy",
                      "N/A" if np.isnan(hc) else f"{hc*100:.1f}%")
            st.caption(f"High-confidence games: {r['high_conf_games']}")
            with st.expander("Elo ratings"):
                ratings = pd.DataFrame(
                    sorted(r["ratings"].items(), key=lambda x: -x[1]),
                    columns=["Team","Elo"]
                )
                st.dataframe(ratings, use_container_width=True, hide_index=True)
        except Exception as e:
            st.error(f"Backtest error: {e}")

st.markdown("---")
st.caption("This website uses the model contained in the uploaded Python predictor. Statistical predictions can be wrong.")
