# Basketball Predictor Web App

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy
Upload `app.py` and `requirements.txt` to a Streamlit-compatible hosting service.

## CSV format
Required columns:
`date,home,away,home_score,away_score`

The app keeps the uploaded predictor's core Elo, rolling-form features, logistic regression, gradient boosting, ensemble weighting, prediction, and backtesting approach.
